package pl.santander.logtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogTestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
