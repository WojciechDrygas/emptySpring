package pl.santander.logtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogTestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogTestAppApplication.class, args);
	}

}
